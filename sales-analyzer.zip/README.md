# 📊 Sales Analyzer

A Python script to analyze sales data and identify the best-performing item.

## 🧮 Features
- Calculates total revenue
- Identifies the best-selling item
- Uses simple Python dictionaries and logic

## 🚀 How to Use

Run the script directly:

```
python sales_analysis.py
```

Modify `sales_data` in the script to add your own items.

## 💡 Example Output

```
Total Sales: $1187.50
Best Selling Item: Eraser ($225.00)
```

## 📄 License
MIT License
